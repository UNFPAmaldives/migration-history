chord-transitions
=================

Need bower installed.

1. Clone the repo and cd into the directory
3. bower install
4. python -m SimpleHTTPServer 8000 (or your favorite local server)
5. open the files in your browser at localhost:8000

BLOG ARTICLE HERE: <a href="http://www.delimited.io/blog/2014/11/18/interactive-chord-diagrams-in-d3">LINK</a>

DEMO HERE: <a href="http://projects.delimited.io/experiments/chord-transitions/demos/trade.html">LINK</a>
